# brother-ql1100-macos-fix

> **The complete fix for Brother QL-1100 not printing on macOS Sequoia / macOS 26**  
> Works with COLORWING and genuine Brother DK-1241 compatible 4×6" rolls.  
> Includes shipping label generator, QR code printer, and folder watch mode.

---

## One-Line Install

```bash
curl -fsSL https://raw.githubusercontent.com/YOUR_USERNAME/brother-ql1100-macos-fix/main/install.sh | bash
```

Then run:
```bash
sudo python3 ~/brother-ql1100-macos-fix/brother_ql1100_fix.py
```

---

## The Problem

After installing the Brother QL-1100 driver on macOS 13+, the printer shows up in System Settings but **all print jobs fail silently** with errors like:

```
STATE: com.brother-paper-size-error
rastertobrotherQL1100 crashed on signal 11
printer-state-message = "Filter failed"
```

P-touch Editor also shows **duplicate QL-1100(USB)** entries.

---

## Root Causes & Fixes

| # | Error | Cause | Fix Applied |
|---|-------|-------|-------------|
| 1 | `paper-size-error` loop | Wrong CUPS media code sent to printer | Use `media=DC16` — Brother's PPD name for 102×152mm |
| 2 | Filter crash (signal 11) | PDF canvas dimensions don't match PPD | Build PDF at exactly **288.00 × 432.96 pt** |
| 3 | Jobs stuck forever | Previous failed jobs block queue | Flush CUPS spool + cancel all jobs |
| 4 | P-touch Editor duplicates | Sandboxed container caches stale printer | Wipe `~/Library/Containers/com.brother.PtouchEditor` |

**The critical discovery:** The Brother PPD names DK-1241 internally as `DC16`.  
Passing `media=Custom.4x6in` or `media=w10200h15200` causes crashes. Always use `-o media=DC16`.

---

## Features

| Command | What it does |
|---------|-------------|
| `sudo python3 brother_ql1100_fix.py` | Full fix — clears queue, reconfigures printer, test print |
| `--diag` | Full diagnostic report, no changes |
| `--diag --save-report` | Save diagnostic to Desktop |
| `--test-print` | Print a test label |
| `--print-file label.pdf` | Print any PDF with correct settings |
| `--shipping` | Interactive shipping label generator |
| `--qr "https://mysite.com"` | Generate + print a QR code label |
| `--watch ~/Desktop/labels` | Auto-print any PDF dropped in folder |
| `--clean-ptouch` | Fix P-touch Editor duplicate entries |
| `--list-media` | Show all supported DK label codes |
| `--media DC03` | Use a different label size |
| `--copies 3` | Print multiple copies |

---

## Usage Examples

```bash
# Full fix (default: DC16 = DK-1241 4x6")
sudo python3 brother_ql1100_fix.py

# Fix for DK-1201 address labels
sudo python3 brother_ql1100_fix.py --media DC03

# Diagnose without making any changes
sudo python3 brother_ql1100_fix.py --diag

# Print a shipping label interactively
sudo python3 brother_ql1100_fix.py --shipping

# Generate a QR code label
sudo python3 brother_ql1100_fix.py --qr "https://dcomputerrepair.com" --qr-title "D's Computer Repair"

# Auto-print any PDF you drop in a folder
python3 brother_ql1100_fix.py --watch ~/Desktop/PrintQueue

# Print a specific file
sudo python3 brother_ql1100_fix.py --print-file ~/Documents/invoice.pdf

# See all supported label sizes
python3 brother_ql1100_fix.py --list-media
```

---

## Requirements

- macOS 13 Ventura or later (tested on macOS 15 Sequoia / macOS 26)
- Apple Silicon or Intel Mac
- Python 3.8+
- Brother QL-1100 driver from [Brother's support site](https://support.brother.com/g/b/downloadlist.aspx?c=us&lang=en&prod=lpql1100eus&os=10069)
- `pip3 install reportlab "qrcode[pil]"` (auto-installed on first run)

---

## Printing from Python

```python
from reportlab.pdfgen import canvas
import subprocess

# Canvas MUST match PPD DC16 dimensions exactly
W, H = 288.00, 432.96  # points — DK-1241 102x152mm 4x6"

c = canvas.Canvas("/tmp/label.pdf", pagesize=(W, H))
c.setFont("Helvetica-Bold", 24)
c.drawCentredString(W/2, H/2, "Your Label Text")
c.save()

subprocess.run([
    "lp", "-d", "Brother_QL1100",
    "-o", "media=DC16",
    "-o", "orientation-requested=3",
    "-o", "fit-to-page=false",
    "/tmp/label.pdf"
])
```

---

## Manual Fix (no script)

```bash
# 1. Cancel stuck jobs
cancel -a Brother_QL1100 2>/dev/null

# 2. Flush CUPS
sudo launchctl unload /System/Library/LaunchDaemons/org.cups.cupsd.plist
sudo rm -f /var/spool/cups/c* /var/spool/cups/d* 2>/dev/null
sudo launchctl load /System/Library/LaunchDaemons/org.cups.cupsd.plist
sleep 3

# 3. Get your USB serial
/usr/libexec/cups/backend/usb 2>&1 | grep -i brother

# 4. Recreate printer with correct media
lpadmin -x Brother_QL1100 2>/dev/null
lpadmin -p Brother_QL1100 -E \
  -v "usb://Brother/QL-1100?serial=YOUR_SERIAL_HERE" \
  -P "/Library/Printers/PPDs/Contents/Resources/Brother QL-1100 CUPS.gz" \
  -D "Brother QL-1100"

# 5. Set DC16 as default (THIS IS THE KEY FIX)
lpoptions -p Brother_QL1100 -o media=DC16 -o orientation-requested=3 -o fit-to-page=false

# 6. Print
lp -d Brother_QL1100 -o media=DC16 -o orientation-requested=3 yourfile.pdf
```

---

## Troubleshooting

**Printer not detected:**
- Check USB cable and power
- Try Mac's built-in rear USB-A port (bypass hubs)
- USB 1.1 speed (12 Mbps) = bad cable or hub

**Jobs still failing:**
```bash
sudo python3 brother_ql1100_fix.py --diag --save-report
sudo cat /var/log/cups/error_log | grep -i "brother\|signal\|filter" | tail -30
```

**Editor Lite LED is on:**  
Hold the Editor Lite button until the green LED turns off. The printer blocks all printing while Editor Lite mode is active.

**P-touch Editor still shows duplicates:**
```bash
python3 brother_ql1100_fix.py --clean-ptouch
```

**COLORWING rolls not working:**  
These are compatible but lack the auto-detect chip. This is fine — `DC16` bypasses chip detection entirely.

---

## Tested On

| Hardware | macOS | Roll | Result |
|----------|-------|------|--------|
| Mac Studio M4 | macOS 26.5.1 | COLORWING DK-1241 | ✅ |
| Mac Studio M4 | macOS 15.5 | COLORWING DK-1241 | ✅ |

---

## Media Codes

See [MEDIA_CODES.md](MEDIA_CODES.md) for the complete table of all supported DK label sizes.

---

## License

MIT — free to use, modify, and distribute.

---

## Contributing

PRs welcome! If you get this working on other hardware or macOS versions, open an issue with your results.

Found this useful? ⭐ Star the repo so others can find it.
